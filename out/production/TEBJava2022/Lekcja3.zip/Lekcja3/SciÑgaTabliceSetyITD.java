package Lekcja3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class SciągaTabliceSetyITD {

//    ArrayList - mają index - uporządkowana - można dublować wartości
//    HashSet - nie ma indexu - nieuporządkowany - nie można dublować wartości
//    HashMap - nie ma indxu ma klucz - nieuporządkowana - można dublować wartości ale nie można dublować kluczy
}
