package Lekcja1;

public class Zadanie_For {
    public static void main(String[] args) {
        int x = 1;

        for (;x < 100;){
            System.out.println(x);
            x++;
        }
    }
}
