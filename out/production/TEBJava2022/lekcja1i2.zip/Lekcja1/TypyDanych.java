package Lekcja1;

import javax.xml.stream.events.Characters;

public class TypyDanych {
    public static void main(String[] args) {
        // Przed nazwą zmienej musimy podać Typ Danych tej zmiennej
        // konwencja tworzenia zmienej
        // Typ Danych + nazwa zmiennej = wartość zmiennej;
        int nazwaZmiennej = 8;
        String jakisWyraz = "Wyraz";

        System.out.println(jakisWyraz);

//        TYPY DANYCH

//        Liczbowe
//        int czyli liczby całkowite z angielskiego integer,
//        ma liczby w zakresie od -2147483648 do 2147483647

//        long czyli liczby całkowite w zakresie od -9223372036854775808 do 9223372036854775807

//        float czyli liczby zmienno przecinkowe np 3.14, float ma precyzje do 7 liczb po przecinku

//        double liczby zmieno przecikowe z precyzją do 15 liczb po przecinku

        //Raczej nie używamy ich
//        byte - 1 bajt - zakres od -128 do 127
//        short - 2 bajty - zakres od -32 768 do 32 767

//        Characters czyli znaki
//                Zmienna typu znak czyli jedna litera, w pojedynczym '' cudzysłowiu
//                konwecnja tworzenia zmiennej typu Char ( ZNAK)
//                char + nazwa zmiennej = 'x';
//                char znak = 'B';

//            String czyli wyrazy czyli dane typu ciąg znaków
//                konwencja
//                        String + nazwa zmiennej = "możemy podać wiele wyrazów";
//                String wyraz = "wyraz";

//        Boolean czyli dane typu logicznego
//                Operatory logiczne przyjmujące wartość True or Fales

//                int x = -1;
//                boolean czyDodatnia;
//
//        System.out.println(czyDodatnia = x > 0);
//
//                boolean EngineIsOn = false ;
//        System.out.println(EngineIsOn);
//
//Konwersja z liczby zmienno przecinkowej na liczbe całkowitą wymaga manualnej konwersji
//                Natomiast konwersja z liczby całkowitej na zmienno przecinkową odbywa się automatycznie
//        int int1 = 1;
//        double double1 = int1;
//        System.out.println(double1);
//
//        double double2 = 2.95;
//        System.out.println(10*double2);
//
//        int int2 = (int)double2;
//        System.out.println(10*int2);
//        System.out.println((10*double2)-(10*int2));







    }
}
