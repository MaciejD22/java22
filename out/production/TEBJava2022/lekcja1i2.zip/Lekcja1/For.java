package Lekcja1;

public class For {
    public static void main(String[] args) {

//      for (wyrażenie początkowe*; warunek; modyfikator licznika**){
//      blok kodu wkonywany po spełnieniu warunku

//        * wyrażenie początkowe wykonuje się tylko raz, przed wykonaniem bloku kodu
//        ** przy spełnieniu warunku uruchamia się też modyfikator licznika czyli np. zwiększenie licznika +1
//
//      }
        for ( int i = 0; i <10; i++){
            System.out.println(i);
        }

//        foreach specjalna skłądnia pętli for to poruszania się po elementach tablicy
//        for (TypObiektu ( typ danych jaki mam w tablicy) nazwa_obiektu : nazwa_tablicy){
//            blok kodu który chcemy wykonać
//        }



    }

}
