package Lekcja1;

public class Operatory {
    public static void main(String[] args) {

//        Operatory Arytmetyczne
//                + dodawanie
//                        - odejmowanie
//                        * mnożenie
//                        / dzielenie
//                        % modulo czyli reszta z dzielenia
//        System.out.println(10%3);
//            10 = 3*3 + 1
//        System.out.println(10%7);
//        10 = 7*1 + 3
//                      ++ inkrementacja zwieksza wartość o 1
//                      -- dekrementacja zmniejsza wartość o 1

//        Operatory przypisania
//
//                Pojedynczy znak "=" służy do przypisywania wartości do zmiennej
//                int x = 5;
//        x += 5 oznacza to samo co x = x + 5
//        x -= 5 oznacza to samo co x = x - 5
//        x *= 5 oznacza to samo co x = x * 5
//        x /= 5 oznacza to samo co x = x / 5
//        x %= 5 oznacza to samo co x = x % 5

//        Operatory porównania
//                == czyli "równa się"
//                != czyli nie równa się
//                >
//                <
//                >= większy bądź równy
//                <= mniejszy bądź równy

//            Operatory logiczne
//                    && czyli and zwraca nam wartość true jeśli obydwa stwierdzenia są true
//                    || czyli or zwraca nam wartość true jeśli chociaż jedno stwierdzenie jest true
//                    ! czyli not to po prostu zaprzeczenie, z wartości true robi wartość false i odwrotnie

//        Zaokrąglanie w górę
//                po kropce przed f podajemy ilość miejsc po przecinku
//        double piecipol = 5.539328943848;
//        int piec = 5;
//        System.out.format("%.1f%n",piecipol);



    }
}
