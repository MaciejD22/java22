package Lekcja5_OOP_przykład;

public class MojaKlasa {
//    nazywając klasę zaczynamy z dużej litery MojaKlasa -PascalCase
//    metodaPierwza <- przy metodach nazewnictwo z małej litery

    //Pola klasy

    int przykładowePole; // przykładowe pole klasy ( niektózy nazwyają to stan klasy)
    boolean jakieśPoleWartościLogicznej;
    String jakiśString;

//    Metody
    void metodaPrzykładowa(){
    }

    void metodaDruga(){

    }
}
