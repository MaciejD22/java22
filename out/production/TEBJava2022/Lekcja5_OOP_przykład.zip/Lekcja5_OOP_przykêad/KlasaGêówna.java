package Lekcja5_OOP_przykład;

public class KlasaGłówna {
    public static void main(String[] args) {
// Tworzymy nowy obiekt na podstawie klasy - Moja Klasa mając do wykorzystania
// wszystkie jego cechy z klasy MojaKlasa
        MojaKlasa obiektMojaKlasa = new MojaKlasa();
        obiektMojaKlasa.metodaDruga();

//        Możemy tworzyć wiele obiektów na podstawie jednej klasy
        MojaKlasa obiektDrugiMojaKlasa = new MojaKlasa();
        obiektDrugiMojaKlasa.metodaPrzykładowa();

        Metody obiektKlasyMetody = new Metody();
        obiektKlasyMetody.metodaNicNieZwracająca();
        obiektKlasyMetody.metodaZParametrem(2);
        obiektKlasyMetody.metodaZBoolean(false,4);
        obiektKlasyMetody.dodawanie(2,2);
        obiektKlasyMetody.liczbyPoPrzecinku(10);
        obiektKlasyMetody.zmianaWartościLogicznej(true);

        int wynikDodawania = obiektKlasyMetody.dodawanie(2,2);
        System.out.println("Wynik dodawania = " + wynikDodawania);

        double wynikLiczbyPoPrzecinku = obiektKlasyMetody.liczbyPoPrzecinku(10.0);
        System.out.println("Wynik dodawania po przecinku = " + wynikLiczbyPoPrzecinku);

        System.out.println("Zmiana wartości logicznej: " + obiektKlasyMetody.zmianaWartościLogicznej(true));


    }

//    Klasy czyli ang. class możemy wykorzystywać w różny sposób
//    Jak ją tworzyć
}
