package Lekcja4_OOP;

public interface SchematTworzeniaListy {


}
