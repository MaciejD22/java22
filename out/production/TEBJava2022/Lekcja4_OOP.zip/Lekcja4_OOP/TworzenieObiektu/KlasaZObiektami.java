package Lekcja4_OOP.TworzenieObiektu;

public class KlasaZObiektami {

// Pola obiektu określają nam stan danego obiektu w klasie. Dzięki polom obiektu możemy mu nadać pewne cechy np. wiek, imię

    String name; // to są pola obiektu
    int wiek; // to są pola obiektu
    boolean czyZaszczepiony; // to są pola obiektu





}
