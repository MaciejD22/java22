package Lekcja4_OOP;

public enum EnumPrzykład {
}
